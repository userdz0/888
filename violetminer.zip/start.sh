chmod +x violetminer
./violetminer --algorithm chukwav2 --pool eu-de01.miningrigrentals.com:3333 --username userus0.180901 --ssl